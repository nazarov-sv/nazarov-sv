import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Pie,
  PieChart,
  BarChart,
  Bar,
  LabelList,
  Area,
  AreaChart,
} from "recharts";
import { useState } from "react";
import data from "./mock.json";
import "./App.css";

const dataPie = [
  { name: "В пути", value: 620, fill: "#bbc1c5" },
  { name: "Доставлено", value: 300, fill: "#16ba4f" },
  { name: "Возвращено", value: 80, fill: "#f8142f" },
];

const mapper = {
  number1: "активных клиентов",
  number2: "неактивных клиентов",
  number3: "перестали работать",
};

const renderTooltip = (props) => {
  const { active, payload, label } = props;
  if (active) {
    return (
      <div className="custom-tooltip">
        <p>{label}</p>
        {payload.map((item) => (
          <p className="label">
            <span className="marker" style={{ backgroundColor: item.color }} />
            {`${item.value} ${mapper[item.name]}`}
          </p>
        ))}
      </div>
    );
  }

  return null;
};

const renderTooltip2 = (props) => {
  const { active, payload } = props;
  if (active) {
    return (
      <div className="custom-tooltip">
        {payload.map((item) => (
          <p className="label">
            <span className="marker" style={{ backgroundColor: item.color }} />
            {`${item.value} ${mapper[item.name]}`}
          </p>
        ))}
      </div>
    );
  }

  return null;
};

const RenderLineChart = () => {
  const [hidden, setHiddem] = useState({
    number1: false,
    number2: false,
    number3: false,
  });
  return (
    <ResponsiveContainer width="100%" height={500}>
      <LineChart data={data}>
        <Legend
          align="center"
          verticalAlign="bottom"
          onClick={(item, index) =>
            setHiddem({
              ...hidden,
              [item.dataKey]: !hidden[item.dataKey],
            })
          }
          formatter={(item) => mapper[item]}
        />
        <Line
          type="linear"
          dataKey="number1"
          stroke="#16ba4f"
          strokeWidth={3}
          hide={hidden.number1}
        />
        <Line
          type="linear"
          dataKey="number2"
          stroke="#f8142f"
          strokeWidth={3}
          hide={hidden.number2}
        />
        <Line
          type="linear"
          dataKey="number3"
          stroke="#bbc1c5"
          strokeWidth={3}
          hide={hidden.number3}
        />
        <CartesianGrid stroke="#ccc" vertical={false} />
        <XAxis dataKey="date" interval={0} padding={{ left: 24, right: 24 }} />
        <YAxis
          orientation="right"
          domain={[0, (dataMax) => Math.round(dataMax / 1000) * 1000 + 1000]}
          scale={"linear"}
        />

        <Tooltip content={renderTooltip} />
      </LineChart>
    </ResponsiveContainer>
  );
};

const RenderLineChart2 = () => {
  const [hidden, setHiddem] = useState({
    number1: false,
    number2: false,
    number3: false,
  });
  return (
    <ResponsiveContainer width="100%" height={500}>
      <AreaChart data={data}>
        <Legend
          align="center"
          verticalAlign="bottom"
          onClick={(item, index) =>
            setHiddem({
              ...hidden,
              [item.dataKey]: !hidden[item.dataKey],
            })
          }
          formatter={(item) => mapper[item]}
        />
        <Area
          type="linear"
          dataKey="number1"
          stroke="#16ba4f"
          fill="#16ba4f"
          strokeWidth={1}
          hide={hidden.number1}
        />
        <Area
          type="linear"
          dataKey="number2"
          stroke="#f8142f"
          fill="#f8142f"
          strokeWidth={1}
          hide={hidden.number2}
        />
        <Area
          type="linear"
          dataKey="number3"
          stroke="#0990fe"
          fill="#0990fe"
          strokeWidth={1}
          hide={hidden.number3}
        />
        <CartesianGrid stroke="#ccc" vertical={false} />
        <XAxis dataKey="date" interval={0} padding={{ left: 24, right: 24 }} />
        <YAxis
          orientation="right"
          domain={[0, (dataMax) => Math.round(dataMax / 1000) * 1000 + 1000]}
          scale={"linear"}
        />

        <Tooltip content={renderTooltip} />
      </AreaChart>
    </ResponsiveContainer>
  );
};

const renderColorfulLegendText = (value, entry) => {
  const { payload } = entry;

  return (
    <span>
      <div style={{ fontSize: 16, fontWeight: "bold" }}>{value}</div>
      <div style={{ marginTop: 8 }}>{payload.value}</div>
      <div style={{ marginTop: 8 }}>{(payload.percent * 100).toFixed(0)}%</div>
    </span>
  );
};

const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
  index,
}) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.4;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor={x > cx ? "start" : "end"}
      dominantBaseline="central"
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const RenderPieChart = () => {
  return (
    <ResponsiveContainer width={600} height={300}>
      <PieChart data={dataPie} label>
        <Pie
          data={dataPie}
          cx={200}
          cy={140}
          innerRadius={80}
          outerRadius={140}
          dataKey="value"
          label={renderCustomizedLabel}
          labelLine={false}
        />
        <Legend
          layout="vertical"
          iconType="circle"
          align="left"
          verticalAlign="top"
          formatter={renderColorfulLegendText}
        />
      </PieChart>
    </ResponsiveContainer>
  );
};

const RenderBarChart = () => {
  return (
    <ResponsiveContainer width="100%" height={500}>
      <BarChart data={data.slice(0, 6)} label barGap={0} barSize={40}>
        <Legend align="center" verticalAlign="bottom" />

        <CartesianGrid stroke="#ccc" vertical={false} />
        <XAxis dataKey="date" interval={0} padding={{ left: 24, right: 24 }} />
        <YAxis
          orientation="right"
          domain={[0, (dataMax) => Math.round(dataMax / 1000) * 1000 + 1000]}
          scale={"linear"}
        />

        <Tooltip cursor={false} />
        <Bar dataKey="number3" fill="#bbc1c5" />
        <Bar dataKey="number1" fill="#16ba4f" />
        <Bar dataKey="number2" fill="#ff880c" />
      </BarChart>
    </ResponsiveContainer>
  );
};

const RenderBarChart2 = () => {
  return (
    <ResponsiveContainer width="100%" height={500}>
      <BarChart data={data.slice(0, 6)} label barGap={0} barSize={100}>
        <Legend align="center" verticalAlign="bottom" />
        <CartesianGrid stroke="#ccc" vertical={false} />
        <XAxis dataKey="date" interval={0} padding={{ left: 24, right: 24 }} />
        <YAxis
          orientation="right"
          domain={[0, (dataMax) => Math.round(dataMax / 1000) * 1000 + 1000]}
          scale={"linear"}
        />
        <Tooltip cursor={false} />
        <Bar dataKey="number3" stackId="a" fill="#1761bb" />
        <Bar dataKey="number1" stackId="a" fill="#16ba4f" />
        <Bar dataKey="number2" stackId="a" fill="#ff880c" />
        <Bar dataKey="number4" stackId="a" fill="#f8142f" />
      </BarChart>
    </ResponsiveContainer>
  );
};

const renderCustomizedLabel3 = (props) => {
  const { y, height, value } = props;

  return (
    <text x={20} y={y + height - 5 - 20} fill={"black"}>
      {value}
    </text>
  );
};

const TriangleBar = (props) => {
  const { fill, x, y, width, height } = props;
  return (
    <rect
      x={fill === "#16ba4f" ? x : fill === "#d0d7dd" ? x - 15 : x - 30}
      y={y}
      width={width}
      height={height}
      fill={fill}
      rx="7"
      ry="7"
    />
  );
};

const RenderBarChart4 = () => {
  return (
    <ResponsiveContainer width={500} height={230}>
      <BarChart
        width={600}
        height={100}
        data={data.slice(0, 4)}
        layout="vertical"
        barSize={15}
        minPointSize={5}
        margin={{ top: 25, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="date" hide />
        <Tooltip content={renderTooltip2} cursor={false} />
        <Bar dataKey="number1" stackId="a" fill="#16ba4f" />
        <Bar dataKey="number3" stackId="a" fill="#d0d7dd">
          <LabelList
            dataKey="name"
            content={renderCustomizedLabel3}
            position="top"
          />
        </Bar>

        <Bar dataKey="number2" stackId="a" fill="red" />
      </BarChart>
    </ResponsiveContainer>
  );
};

const RenderBar5Chart = () => {
  return (
    <ResponsiveContainer width={500} height={230}>
      <BarChart
        width={600}
        height={100}
        data={data.slice(0, 4)}
        layout="vertical"
        barSize={15}
        minPointSize={5}
        margin={{ top: 25, right: 30, left: 20, bottom: 5 }}
      >
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="date" hide />
        <Tooltip content={renderTooltip2} cursor={false} />
        <Bar
          dataKey="number1"
          stackId="a"
          fill="#16ba4f"
          shape={<TriangleBar />}
        />
        <Bar
          dataKey="number3"
          stackId="a"
          fill="#d0d7dd"
          shape={<TriangleBar />}
        >
          <LabelList
            dataKey="name"
            content={renderCustomizedLabel3}
            position="top"
          />
        </Bar>
        <Bar dataKey="number2" stackId="a" fill="red" shape={<TriangleBar />} />
      </BarChart>
    </ResponsiveContainer>
  );
};

export const RechartsRender = () => {
  return (
    <div>
      <h2>ReCharts</h2>
      <div>
        <RenderLineChart />
      </div>
      <div>
        <RenderLineChart2 />
      </div>
      <div style={{ marginLeft: 200, marginTop: 100 }} className="pie">
        <RenderPieChart />
      </div>

      <div style={{ marginTop: 100 }}>
        <RenderBarChart />
      </div>

      <div style={{ marginTop: 100 }}>
        <RenderBarChart2 />
      </div>

      <div style={{ marginTop: 100 }}>
        <RenderBarChart4 />
      </div>

      <div style={{ marginTop: 100 }}>
        <RenderBar5Chart />
      </div>
    </div>
  );
};
