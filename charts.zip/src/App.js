import { RechartsRender } from "./Recharts";
import "./App.css";

function App() {
  return (
    <div className="App">
      <RechartsRender />
      <div style={{ height: 300, width: 100 }}></div>
    </div>
  );
}

export default App;
